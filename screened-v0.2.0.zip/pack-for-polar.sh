#!/bin/sh
# Zip this folder for a Polar file-download product. Does not publish anything.
set -eu
cd "$(dirname "$0")"
ver="$(tr -d '[:space:]' < VERSION)"
out="${1:-screened-v${ver}.zip}"
python3 - "$out" << 'PY'
import sys, zipfile
from pathlib import Path
root = Path(".")
out = sys.argv[1]
skip = {"__pycache__", ".pyc", ".DS_Store"}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob("*")):
        if p.is_dir():
            continue
        if p.name.endswith(".zip"):
            continue
        if any(part in skip or part.endswith(".pyc") for part in p.parts):
            continue
        z.write(p, p.as_posix())
        print(p.as_posix())
print("Wrote", Path(out).resolve())
PY
